﻿using Microsoft.AspNetCore.Mvc;
using NotesManagement.Models;
using System.Diagnostics;

namespace NotesManagement.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        NotesContext context = new NotesContext();

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }


        [HttpPost]
        public IActionResult Index(string userId, string password)
        {

            var user = context.Users.Where(u => u.UserId == userId && u.Password == password).FirstOrDefault();

            if (user == null)
            {
                ViewBag.Msg = "Login Failed";
            }
            else
            {
                HttpContext.Session.SetString("UserId", userId);
                HttpContext.Session.SetString("FullName", user.FullName);

                return RedirectToAction("DisplayNotes");

            }

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }


        [HttpGet]
        public IActionResult CreateNote()
        {
            string UserId = HttpContext.Session.GetString("UserId");
            string FullName = HttpContext.Session.GetString("FullName");

            if (UserId == null)
            {
                return RedirectToAction("Index");
            }



            ViewBag.Msg = "Welcome " + FullName;

            return View();
        }

        [HttpPost]
        public IActionResult CreateNote(DateTime DateOfNote, string NoteText)
        {
            string UserId = HttpContext.Session.GetString("UserId");
            string FullName = HttpContext.Session.GetString("FullName");


            if (UserId == null)
            {
                return RedirectToAction("Index");
            }

            ViewBag.Msg = "Welcome " + FullName;

            Note note = new Note();
            note.DateOfNote = DateOfNote;
            note.NoteText = NoteText;
            note.UserId = UserId;

            context.Notes.Add(note);
            context.SaveChanges();



            return RedirectToAction("DisplayNotes");
        }

        public IActionResult DisplayNotes()
        {
            string UserId = HttpContext.Session.GetString("UserId");
            string FullName = HttpContext.Session.GetString("FullName");

            if(UserId == null)
            {
                return RedirectToAction("Index");
            }


            ViewBag.FullName = FullName;

            return View( context.Notes.Where(n=>n.UserId == UserId).ToList());
        }


        [HttpGet]
        public IActionResult Delete(int id)
        {
            var note = context.Notes.Where(n => n.NoteId == id).FirstOrDefault();
            return View(note);
        }

        [HttpPost]
        [ActionName("Delete")]
        public IActionResult DeletePost(int id)
        {
            var note = context.Notes.Where(n => n.NoteId == id).FirstOrDefault();

            context.Notes.Remove(note);
            context.SaveChanges();

            return RedirectToAction("DisplayNotes");
        }

    }
}