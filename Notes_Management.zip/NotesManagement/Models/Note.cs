﻿using System;
using System.Collections.Generic;

namespace NotesManagement.Models;

public partial class Note
{
    public int NoteId { get; set; }

    public string UserId { get; set; }

    public DateTime? DateOfNote { get; set; }

    public string NoteText { get; set; }

    public virtual User User { get; set; }
}
