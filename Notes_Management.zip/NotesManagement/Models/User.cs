﻿using System;
using System.Collections.Generic;

namespace NotesManagement.Models;

public partial class User
{
    public string UserId { get; set; }

    public string Password { get; set; }

    public string FullName { get; set; }

    public virtual ICollection<Note> Notes { get; set; } = new List<Note>();
}
